(() => {
"use strict";
const WS_URL = "wss://api.derivws.com/trading/v1/options/ws/public";
const $ = id => document.getElementById(id);
const state = {
  ws:null, symbols:[], ticks:[], currentSymbol:"", pipSize:2, requestId:10,
  symbolsRequestId:null, historyRequestId:null, tickSubscriptionId:null,
  reconnectTimer:null, statusTimer:null, connectAttempts:0, intentionalClose:false,
  lastMessage:"None", lastRequest:"None", lastError:"None", lastTickAt:null,
  liveTicks:0, evalHits:0, evalCount:0
};
const num = (v, fallback=0) => Number.isFinite(Number(v)) ? Number(v) : fallback;
const precision = (v, fallback=2) => Number.isInteger(Number(v)) && Number(v)>=0 && Number(v)<=10 ? Number(v) : fallback;
const nextId = () => ++state.requestId;
const pct = (n,d) => d ? (100*n/d).toFixed(1)+"%" : "—";
const set = (id,v) => { const n=$(id); if(n) n.textContent=String(v); };

function addPanels() {
  if (!$("diagnosticsPanel")) {
    document.querySelector(".controls").insertAdjacentHTML("afterend",
      '<section id="diagnosticsPanel" class="panel section"><div class="section-head"><div><p class="eyebrow">LIVE DATA MONITOR</p><h2>Connection diagnostics</h2></div><span id="diagHealth" class="tag">Waiting for feed</span></div><div class="diag-grid"><div><span>Selected market</span><strong id="diagMarket">—</strong></div><div><span>Tick subscription</span><strong id="diagSubscription">Not started</strong></div><div><span>Last message</span><strong id="diagMessage">None</strong></div><div><span>Last live tick</span><strong id="diagLastTick">Waiting</strong></div><div><span>Live ticks received</span><strong id="diagLiveCount">0</strong></div><div><span>Sample size</span><strong id="diagSample">0</strong></div><div><span>Last request</span><strong id="diagRequest">None</strong></div><div><span>Last API error</span><strong id="diagError">None</strong></div></div><p class="footnote">Socket connection and market subscription are tracked separately.</p></section>');
  }
  if (!$("advancedAnalytics")) {
    $("diagnosticsPanel").insertAdjacentHTML("afterend",
      '<section id="advancedAnalytics" class="panel section"><div class="section-head"><div><p class="eyebrow">ADVANCED STATISTICS</p><h2>Pattern and distribution analysis</h2></div><span class="tag">Descriptive, not predictive</span></div><div class="advanced-grid"><div class="advanced-card"><span>Distribution entropy</span><strong id="entropyValue">—</strong><small id="entropyNote">Waiting for data</small></div><div class="advanced-card"><span>Current parity streak</span><strong id="parityStreak">—</strong><small id="parityNote">Waiting for data</small></div><div class="advanced-card"><span>Repeated digit streak</span><strong id="repeatStreak">—</strong><small id="repeatNote">Waiting for data</small></div><div class="advanced-card"><span>Largest frequency shift</span><strong id="shiftValue">—</strong><small id="shiftNote">Waiting for data</small></div></div><div class="advanced-columns"><div><h3>Hot digits</h3><p id="hotDigits">Waiting for data</p></div><div><h3>Cold digits</h3><p id="coldDigits">Waiting for data</p></div><div><h3>Recent frequency shifts</h3><p id="frequencyShifts">Waiting for data</p></div><div><h3>Common digit transitions</h3><p id="transitions">Waiting for data</p></div></div><p class="footnote">These statistics describe the selected sample. They do not guarantee future outcomes.</p></section>');
  }
  if (!$("digitScopeStyles")) {
    const s=document.createElement("style"); s.id="digitScopeStyles";
    s.textContent=".diag-grid,.advanced-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.diag-grid>div,.advanced-card,.advanced-columns>div{padding:12px;min-width:0;background:#0a1725;border:1px solid #1c3045;border-radius:10px}.diag-grid span,.advanced-card span,.advanced-card small{display:block;color:var(--muted);font-size:10px}.diag-grid strong{display:block;margin-top:5px;font-size:12px;overflow-wrap:anywhere}.advanced-grid{margin-bottom:14px}.advanced-card strong{display:block;margin-top:5px;font-size:19px;color:var(--green)}.advanced-card small{margin-top:3px}.advanced-columns{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.advanced-columns h3{font-size:13px;margin:0 0 8px}.advanced-columns p{margin:0;color:var(--muted);font-size:12px;line-height:1.8;overflow-wrap:anywhere}@media(max-width:700px){.diag-grid,.advanced-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.advanced-columns{grid-template-columns:1fr}}";
    document.head.appendChild(s);
  }
}
function diagnostics() {
  const age=state.lastTickAt ? Math.floor((Date.now()-state.lastTickAt)/1000) : null;
  set("diagMarket",state.currentSymbol||"—");
  set("diagSubscription",state.tickSubscriptionId?"Active · stream confirmed":state.historyRequestId!==null?"Request sent · awaiting response":"Not started");
  set("diagMessage",state.lastMessage);
  set("diagLastTick",age===null?"Waiting":age+"s ago");
  set("diagLiveCount",state.liveTicks);
  set("diagSample",state.ticks.length+" ticks");
  set("diagRequest",state.lastRequest);
  set("diagError",state.lastError);
  set("diagHealth",age!==null&&age<=15?"Live data flowing":state.historyRequestId!==null?"Waiting for market data":"No live data yet");
}
function connection(status,message) {
  const dot=$("connectionDot");
  dot.classList.toggle("online",status==="online");
  dot.classList.toggle("offline",status==="offline");
  set("connectionText",message);
  set("feedStatus",status==="online"?"Socket open":status==="connecting"?"Connecting":"Offline");
  diagnostics();
}
function error(message) {
  $("errorBox").hidden=false; $("errorBox").textContent=message;
  state.lastError=message; diagnostics();
}
function clearError() {
  $("errorBox").hidden=true; $("errorBox").textContent="";
  state.lastError="None"; diagnostics();
}
function send(payload) {
  if(!state.ws||state.ws.readyState!==WebSocket.OPEN) return false;
  state.ws.send(JSON.stringify(payload));
  const action=Object.keys(payload).find(k=>k!=="req_id");
  state.lastRequest=action ? action+": "+String(payload[action]) : "request";
  diagnostics(); return true;
}
function requestSymbols() {
  if(state.symbolsRequestId!==null)return;
  state.symbolsRequestId=nextId();
  if(!send({active_symbols:"brief",req_id:state.symbolsRequestId}))state.symbolsRequestId=null;
}
function connect() {
  clearTimeout(state.reconnectTimer); state.intentionalClose=false;
  connection("connecting","Connecting to Deriv public market data…");
  try { state.ws=new WebSocket(WS_URL); }
  catch(e){error("Could not start WebSocket: "+(e.message||"browser error"));reconnect();return;}
  state.ws.onopen=()=>{state.connectAttempts=0;state.symbolsRequestId=null;clearError();connection("online","Socket open · requesting markets");requestSymbols();};
  state.ws.onmessage=event=>{
    let d; try{d=JSON.parse(event.data);}catch{state.lastMessage="Unparseable message";diagnostics();return;}
    state.lastMessage=d.msg_type||(d.error?"error":"message"); diagnostics();
    if(d.error){
      const req=d.echo_req||{};
      if(req.active_symbols){state.symbolsRequestId=null;set("marketCount","Market list request failed");}
      if(req.ticks_history){
        if(d.req_id&&state.historyRequestId&&d.req_id!==state.historyRequestId)return;
        state.historyRequestId=null;state.tickSubscriptionId=null;set("sampleNote","Market data request rejected");
      }
      error("Deriv API error: "+(d.error.message||d.error.code||"Unknown API error"));return;
    }
    if(d.msg_type==="active_symbols"||Array.isArray(d.active_symbols)){
      state.symbolsRequestId=null;handleSymbols(Array.isArray(d.active_symbols)?d.active_symbols:[]);return;
    }
    if(d.msg_type==="history"||d.history?.prices){handleHistory(d);return;}
    if(d.msg_type==="tick"&&d.tick)handleTick(d.tick,d.subscription,d.echo_req,d.req_id);
  };
  state.ws.onerror=()=>{connection("offline","WebSocket transport error");error("Deriv WebSocket transport error. Reconnecting…");};
  state.ws.onclose=()=>{connection("offline","Disconnected · reconnecting");state.symbolsRequestId=null;state.historyRequestId=null;state.tickSubscriptionId=null;if(!state.intentionalClose)reconnect();};
}
function reconnect() {
  if(state.intentionalClose||state.reconnectTimer)return;
  state.connectAttempts++;
  const delay=Math.min(20000,1200*Math.pow(1.7,Math.min(state.connectAttempts,7)));
  state.reconnectTimer=setTimeout(()=>{state.reconnectTimer=null;connect();},delay);
}
function normalize(item) {
  const symbol=item.symbol||item.underlying_symbol||"";
  return {...item,symbol,display_name:item.display_name||item.underlying_symbol_name||item.name||symbol};
}
function synthetic(item) {
  const x=normalize(item);
  return /synthetic|derived/i.test([x.market,x.submarket,x.subgroup].join(" "))||
    /volatility|crash|boom|step|jump|range break|drift/i.test(x.display_name)||
    /^(R_|1HZ|JD|CRASH|BOOM|STPRNG)/i.test(x.symbol);
}
function handleSymbols(list) {
  const all=list.map(normalize).filter(x=>x.symbol);
  const filtered=all.filter(synthetic);
  state.symbols=(filtered.length?filtered:all).sort((a,b)=>a.display_name.localeCompare(b.display_name));
  const select=$("symbolSelect"), previous=state.currentSymbol;
  select.replaceChildren();
  if(!state.symbols.length){select.add(new Option("No markets returned",""));set("marketCount","0 markets returned");error("Deriv returned an empty active-symbol list.");return;}
  state.symbols.forEach(x=>select.add(new Option(x.display_name,x.symbol)));
  const chosen=state.symbols.find(x=>x.symbol===previous)||state.symbols.find(x=>/volatility 100/i.test(x.display_name))||state.symbols.find(x=>/volatility 75/i.test(x.display_name))||state.symbols[0];
  select.value=chosen.symbol;set("marketCount",state.symbols.length+" synthetic markets available");clearError();chooseSymbol(chosen.symbol);
}
function forgetSubscription() {
  if(state.tickSubscriptionId){send({forget:state.tickSubscriptionId,req_id:nextId()});state.tickSubscriptionId=null;}
}
function chooseSymbol(symbol) {
  if(!symbol)return;
  state.currentSymbol=symbol;
  if(!state.ws||state.ws.readyState!==WebSocket.OPEN){set("sampleNote","Waiting for Deriv connection…");diagnostics();return;}
  forgetSubscription();state.ticks=[];state.evalHits=0;state.evalCount=0;
  state.lastTickEpoch=null;state.lastTickAt=null;state.liveTicks=0;state.historyRequestId=nextId();
  set("latestQuote","—");set("latestDigit","—");set("latestTime","Waiting for first live tick");
  set("sampleNote","Requesting history and live subscription…");$("digitBars").replaceChildren();
  set("marketLabel",$("symbolSelect").selectedOptions[0]?.text||symbol);renderEmpty();diagnostics();
  // Deriv supports subscribe: 1 on ticks_history: history first, then live tick messages.
  const ok=send({ticks_history:symbol,count:Number($("windowSelect").value),end:"latest",style:"ticks",subscribe:1,req_id:state.historyRequestId});
  if(!ok){state.historyRequestId=null;error("Market data request could not be sent because the socket is not open.");}
}
function makeTick(quote,epoch,pip) {
  const q=num(quote,NaN);if(!Number.isFinite(q))return null;
  const p=precision(pip,state.pipSize), digit=Number(q.toFixed(p).replace(".","").replace("-","").slice(-1));
  return Number.isInteger(digit)?{quote:q,epoch:num(epoch,0),digit}:null;
}
function key(t){return t.epoch? t.epoch+":"+t.quote : "noepoch:"+t.quote+":"+t.digit;}
function unique(items){const m=new Map();items.forEach(t=>{if(t)m.set(key(t),t);});return Array.from(m.values()).sort((a,b)=>a.epoch-b.epoch);}
function handleHistory(d) {
  if(d.req_id&&state.historyRequestId&&d.req_id!==state.historyRequestId){if(d.subscription?.id)send({forget:d.subscription.id,req_id:nextId()});return;}
  if(d.echo_req?.ticks_history&&d.echo_req.ticks_history!==state.currentSymbol){if(d.subscription?.id)send({forget:d.subscription.id,req_id:nextId()});return;}
  if(!Array.isArray(d.history?.prices))return;
  state.tickSubscriptionId=d.subscription?.id||state.tickSubscriptionId;
  state.pipSize=precision(d.pip_size,state.pipSize);
  const hist=d.history.prices.map((p,i)=>makeTick(p,d.history.times?.[i],state.pipSize)).filter(Boolean);
  state.ticks=unique([...hist,...state.ticks]).slice(-Math.max(1000,Number($("windowSelect").value)));
  state.evalHits=0;state.evalCount=0;
  for(let i=30;i<state.ticks.length;i++){const guess=predict(state.ticks.slice(Math.max(0,i-100),i));state.evalCount++;if(guess===state.ticks[i].digit)state.evalHits++;}
  set("sampleNote",state.ticks.length+" historical ticks loaded · live subscription "+(state.tickSubscriptionId?"confirmed":"awaiting ID"));
  if(state.ticks.length)latest(state.ticks[state.ticks.length-1],false);
  render();diagnostics();
}
function predict(items) {
  if(!items.length)return null;const c=Array(10).fill(0);
  items.slice(-100).forEach(t=>c[t.digit]++);return c.indexOf(Math.max(...c));
}
function handleTick(tick,sub,echo,reqId) {
  const symbol=tick?.symbol||echo?.ticks||echo?.ticks_history;
  if(symbol&&symbol!==state.currentSymbol)return;
  if(sub?.id&&state.tickSubscriptionId&&sub.id!==state.tickSubscriptionId)return;
  if(reqId&&state.historyRequestId&&reqId!==state.historyRequestId)return;
  if(sub?.id)state.tickSubscriptionId=sub.id;
  state.pipSize=precision(tick.pip_size,state.pipSize);
  const t=makeTick(tick.quote,tick.epoch,state.pipSize);if(!t)return;
  if(state.ticks.some(x=>key(x)===key(t)))return;
  const guess=state.ticks.length>=30?predict(state.ticks):null;
  if(guess!==null){state.evalCount++;if(guess===t.digit)state.evalHits++;}
  state.ticks.push(t);state.ticks=unique(state.ticks).slice(-Math.max(1000,Number($("windowSelect").value)));
  state.lastTickEpoch=t.epoch||state.lastTickEpoch;state.lastTickAt=Date.now();state.liveTicks++;
  latest(t,true);render();set("sampleNote",state.ticks.length+" ticks in memory · live updates confirmed");diagnostics();
}
function latest(t,live) {
  set("latestQuote",t.quote.toFixed(state.pipSize));set("latestDigit",t.digit);
  set("latestTime",t.epoch?new Date(t.epoch*1000).toLocaleTimeString()+(live?" · live":" · history"):(live?"Live tick received":"Historical sample"));
}
function renderEmpty() {
  ["evenPct","oddPct","overPct","underPct","equalPct","matchPct","diffPct","overUnderN"].forEach(id=>set(id,"—"));
  set("tickCount","0");set("accuracy","Collecting data");set("topDigits","Waiting for data");
  ["evenMeter","matchMeter","overMeter"].forEach(id=>{if($(id))$(id).style.width="0%";});
  ["entropyValue","parityStreak","repeatStreak","shiftValue"].forEach(id=>set(id,"—"));
  ["hotDigits","coldDigits","frequencyShifts","transitions"].forEach(id=>set(id,"Waiting for data"));
}
function advanced(sample,counts) {
  const n=sample.length;let h=0;counts.forEach(x=>{if(x){const p=x/n;h-=p*Math.log(p);}});
  set("entropyValue",(100*h/Math.log(10)).toFixed(1)+" / 100");
  set("entropyNote","Evenness of observed digit distribution");
  const last=sample[n-1].digit,parity=last%2?"Odd":"Even";let ps=0,rs=0;
  for(let i=n-1;i>=0&&((sample[i].digit%2?"Odd":"Even")===parity);i--)ps++;
  for(let i=n-1;i>=0&&sample[i].digit===last;i--)rs++;
  set("parityStreak",ps+" "+parity);set("parityNote","Current run · last digit "+last);
  set("repeatStreak",rs+" × "+last);set("repeatNote","Consecutive identical digits");
  const rank=counts.map((count,digit)=>({digit,count})).sort((a,b)=>b.count-a.count||a.digit-b.digit);
  set("hotDigits",rank.slice(0,3).map(x=>x.digit+": "+x.count+" ("+pct(x.count,n)+")").join(" · "));
  set("coldDigits",rank.slice(-3).reverse().map(x=>x.digit+": "+x.count+" ("+pct(x.count,n)+")").join(" · "));
  const recent=sample.slice(-Math.min(100,n)),prior=sample.slice(-Math.min(200,n),-Math.min(100,n));
  if(recent.length>=30&&prior.length>=30){
    const a=Array(10).fill(0),b=Array(10).fill(0);recent.forEach(x=>a[x.digit]++);prior.forEach(x=>b[x.digit]++);
    const shifts=a.map((v,digit)=>({digit,delta:100*(v/recent.length-b[digit]/prior.length)})).sort((x,y)=>Math.abs(y.delta)-Math.abs(x.delta));
    set("shiftValue",(shifts[0].delta>=0?"+":"")+shifts[0].delta.toFixed(1)+" pp");
    set("shiftNote","Digit "+shifts[0].digit+" · recent vs prior 100");
    set("frequencyShifts",shifts.slice(0,4).map(x=>x.digit+": "+(x.delta>=0?"+":"")+x.delta.toFixed(1)+" pp").join(" · "));
  }else{set("shiftValue","Need 60+ ticks");set("shiftNote","Comparing adjacent samples");set("frequencyShifts","Collect at least 60 observations");}
  const pairs=new Map();for(let i=1;i<n;i++){const k=sample[i-1].digit+"→"+sample[i].digit;pairs.set(k,(pairs.get(k)||0)+1);}
  set("transitions",Array.from(pairs.entries()).sort((a,b)=>b[1]-a[1]).slice(0,4).map(x=>x[0]+": "+x[1]).join(" · ")||"Need more ticks");
}
function render() {
  const sample=state.ticks.slice(-Number($("windowSelect").value));if(!sample.length){renderEmpty();return;}
  const counts=Array(10).fill(0);sample.forEach(t=>counts[t.digit]++);const max=Math.max(...counts,1);
  $("digitBars").innerHTML=counts.map((count,digit)=>'<div class="digit"><div class="bar-track"><div class="bar" style="height:'+(count/max*100)+'%"></div></div><b>'+digit+'</b><small>'+pct(count,sample.length)+'</small></div>').join("");
  const even=counts[0]+counts[2]+counts[4]+counts[6]+counts[8],odd=sample.length-even;
  set("evenPct",pct(even,sample.length));set("oddPct",pct(odd,sample.length));$("evenMeter").style.width=(100*even/sample.length)+"%";
  const barrier=Number($("barrierSelect").value),over=counts.slice(barrier+1).reduce((a,b)=>a+b,0),under=counts.slice(0,barrier).reduce((a,b)=>a+b,0),equal=counts[barrier],eligible=over+under;
  set("overPct",pct(over,eligible));set("underPct",pct(under,eligible));set("equalPct",pct(equal,sample.length));set("overUnderN",eligible);$("overMeter").style.width=(eligible?100*over/eligible:0)+"%";
  const d=Number($("matchDigit").value),matches=counts[d];set("matchPct",pct(matches,sample.length));set("diffPct",pct(sample.length-matches,sample.length));$("matchMeter").style.width=(100*matches/sample.length)+"%";
  const ranked=counts.map((count,digit)=>({count,digit})).sort((a,b)=>b.count-a.count||a.digit-b.digit);
  set("topDigits",ranked.slice(0,3).map(x=>x.digit+" ("+pct(x.count,sample.length)+")").join(" · "));
  set("tickCount",sample.length.toLocaleString());set("windowLabel",$("symbolSelect").selectedOptions[0]?.text||state.currentSymbol);
  set("accuracy",state.evalCount?pct(state.evalHits,state.evalCount)+" · "+state.evalCount.toLocaleString()+" test ticks":"Collecting out-of-sample ticks");
  set("modelStatus","Walk-forward frequency baseline · experimental");advanced(sample,counts);
}
function init() {
  addPanels();for(let d=0;d<=9;d++)$("matchDigit").add(new Option(String(d),String(d)));
  $("symbolSelect").addEventListener("change",e=>chooseSymbol(e.target.value));
  $("windowSelect").addEventListener("change",()=>{if(state.currentSymbol)chooseSymbol(state.currentSymbol);});
  $("refreshBtn").addEventListener("click",()=>state.currentSymbol?chooseSymbol(state.currentSymbol):requestSymbols());
  $("barrierSelect").addEventListener("change",render);$("matchDigit").addEventListener("change",render);
  state.statusTimer=setInterval(diagnostics,1000);
}
window.addEventListener("beforeunload",()=>{state.intentionalClose=true;clearTimeout(state.reconnectTimer);clearInterval(state.statusTimer);if(state.ws)state.ws.close();});
init();connect();
})();